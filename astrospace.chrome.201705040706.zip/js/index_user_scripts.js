/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* graphic button  Emergency to Earth */
    $(document).on("click", ".uib_w_3", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#emergencyToearth"); 
         return false;
    });
    
        /* button  Cancle */
    
    
        /* graphic button  SpaceShip */
    $(document).on("click", ".uib_w_4", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#SpaceShip"); 
         return false;
    });
    
        /* button  Cancle */
    
    
        /* button  Cancle */
    $(document).on("click", ".uib_w_20", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_63_24"); 
         return false;
    });
    
        /* button  Emergency */
    $(document).on("click", ".uib_w_15", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#emergencyToearth"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_16", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_63_24"); 
         return false;
    });
    
        /* graphic button  Earth&Us */
    
    
        /* graphic button  SpaceWeather */
    $(document).on("click", ".uib_w_10", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#Weather"); 
         return false;
    });
    
        /* graphic button  Earth&Us */
    $(document).on("click", ".uib_w_6", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#EarthUs"); 
         return false;
    });
    
        /* graphic button  SpaceMap */
    $(document).on("click", ".uib_w_8", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#SpaceMap"); 
         return false;
    });
    
        /* button  Mars Google API View* */
    $(document).on("click", ".uib_w_34", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#GoogleMars"); 
         return false;
    });
    
        /* button  Record */
    $(document).on("click", ".uib_w_17", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#live"); 
         return false;
    });
    
        /* graphic button  LiveDate */
    $(document).on("click", ".uib_w_12", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#live"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
